# ATOPui

ATOPui is a local, installable React component library derived from the MIT-licensed beUI source. The original author's copyright and license are retained in `LICENSE`.

## Install the local package

```bash
python3 scripts/build-atop-ui.py
bun add ./packages/atop-ui/atop-ui-0.1.0.tgz
```

Run the build from the repository root. Use the generated archive when installing into another project; it keeps that project's React instance shared with ATOPui.

Import the precompiled styles once at your application root:

```tsx
import "@atop/ui/styles.css";
import { Button } from "@atop/ui";
import { OTPInput } from "@atop/ui/blocks/otp-input";
```

The package provides category subpaths for all registry items and variants: `motion`, `agents`, `charts`, and `blocks`. See `dist/manifest.json` for the complete path-to-component list.

## Rebuild

From the repository root, run `python3 scripts/build-atop-ui.py`. The build bundles internal helpers, generates declarations, and compiles the CSS used by the components.
